$port = 45123
$appDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Check if port is already listening
$tcp = New-Object System.Net.Sockets.TcpClient
$async = $tcp.BeginConnect("127.0.0.1", $port, $null, $null)
$wait = $async.AsyncWaitHandle.WaitOne(300, $false)
if ($wait -and $tcp.Connected) {
    $tcp.EndConnect($async)
    $tcp.Close()
    Start-Process msedge -ArgumentList "--app=http://127.0.0.1:$port/" -ErrorAction SilentlyContinue
    exit
}

# Start local HTTP Listener
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:$port/")
$listener.Start()

# Launch Edge or Chrome in App mode
try {
    Start-Process msedge -ArgumentList "--app=http://127.0.0.1:$port/" -ErrorAction Stop
} catch {
    try {
        Start-Process chrome -ArgumentList "--app=http://127.0.0.1:$port/" -ErrorAction Stop
    } catch {
        Start-Process "http://127.0.0.1:$port/"
    }
}

# Serve files
while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
        $request = $context.Request
        $response = $context.Response
        
        $relPath = $request.Url.LocalPath.TrimStart('/')
        if ([string]::IsNullOrEmpty($relPath)) { $relPath = "index.html" }
        $filePath = Join-Path $appDir $relPath
        
        if (Test-Path $filePath -PathType Leaf) {
            $bytes = [System.IO.File]::ReadAllBytes($filePath)
            if ($relPath.EndsWith(".html")) { $response.ContentType = "text/html; charset=utf-8" }
            elseif ($relPath.EndsWith(".js")) { $response.ContentType = "application/javascript; charset=utf-8" }
            elseif ($relPath.EndsWith(".css")) { $response.ContentType = "text/css; charset=utf-8" }
            elseif ($relPath.EndsWith(".png")) { $response.ContentType = "image/png" }
            elseif ($relPath.EndsWith(".ico")) { $response.ContentType = "image/x-icon" }
            elseif ($relPath.EndsWith(".json")) { $response.ContentType = "application/json" }
            
            $response.ContentLength64 = $bytes.Length
            $response.OutputStream.Write($bytes, 0, $bytes.Length)
        } else {
            $indexFile = Join-Path $appDir "index.html"
            if (Test-Path $indexFile -PathType Leaf) {
                $bytes = [System.IO.File]::ReadAllBytes($indexFile)
                $response.ContentType = "text/html; charset=utf-8"
                $response.ContentLength64 = $bytes.Length
                $response.OutputStream.Write($bytes, 0, $bytes.Length)
            } else {
                $response.StatusCode = 404
            }
        }
        $response.Close()
    } catch {
        # ignore client aborted connections
    }
}
