# Setup FinAudit Justice on Windows
$ErrorActionPreference = "Stop"

$currentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$targetDir = [System.IO.Path]::Combine($env:LOCALAPPDATA, "Programs", "FinAuditJustice")

if (-not (Test-Path $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
}

# Copy files
Copy-Item -Path "$currentDir\*" -Destination $targetDir -Recurse -Force

# Create Desktop Shortcut
$desktopPath = [Environment]::GetFolderPath("Desktop")
$shortcutFile = [System.IO.Path]::Combine($desktopPath, "FinAudit Justice.lnk")
$iconPath = [System.IO.Path]::Combine($targetDir, "icon.ico")
$vbsPath = [System.IO.Path]::Combine($targetDir, "launcher.vbs")

$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($shortcutFile)
$sc.TargetPath = "wscript.exe"
$sc.Arguments = "`"$vbsPath`""
$sc.WorkingDirectory = $targetDir
$sc.IconLocation = "$iconPath,0"
$sc.Description = "FinAudit Justice - نظام تدقيق وفحص الصفقات العمومية"
$sc.Save()

# Create Start Menu Shortcut
$startMenuPath = [Environment]::GetFolderPath("Programs")
$smShortcutFile = [System.IO.Path]::Combine($startMenuPath, "FinAudit Justice.lnk")
$sm = $wsh.CreateShortcut($smShortcutFile)
$sm.TargetPath = "wscript.exe"
$sm.Arguments = "`"$vbsPath`""
$sm.WorkingDirectory = $targetDir
$sm.IconLocation = "$iconPath,0"
$sm.Description = "FinAudit Justice - نظام تدقيق وفحص الصفقات العمومية"
$sm.Save()

# Launch the app immediately via launcher.vbs
Start-Process "wscript.exe" -ArgumentList "`"$vbsPath`"" -WorkingDirectory $targetDir
