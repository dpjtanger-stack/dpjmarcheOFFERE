@echo off
set "APP_PATH=%~dp0index.html"
start msedge --app="file:///%APP_PATH%" --allow-file-access-from-files 2>nul || start chrome --app="file:///%APP_PATH%" --allow-file-access-from-files 2>nul || start "" "file:///%APP_PATH%"
exit
